# Blockit APK — phone-only build

1. Create a GitHub repository (a private repo is fine).
2. Upload `Blockit-Android-v1.5.0-Ready.zip` to the repository root.
3. Create this file in GitHub: `.github/workflows/build-apk.yml` and paste the workflow from `.github/workflows/build-apk.yml`.
4. Open **Actions** → **Build Blockit APK** → **Run workflow**.
5. Wait for the green check.
6. Open the completed workflow run and scroll to **Artifacts**.
7. Download `Blockit-Android-v1.5.0-debug`, unzip it, and install the `.apk` on Android.

The workflow installs Android SDK platform 35/build tools and Gradle 8.7 in the GitHub-hosted runner, so no PC or Android Studio is required on the phone.
