# Blockit Android-ready project

This project wraps the existing Blockit v1.5.0 dashboard in a native Android WebView and provides a compatibility layer for the Chrome-extension storage APIs used by the dashboard.

## Included
- Existing Blockit v1.5.0 HTML/CSS/JS/assets
- Native Android launcher/activity
- Persistent Android SharedPreferences-backed `chrome.storage.local` compatibility
- DOM storage enabled
- Notification permission/channel foundation
- Portrait mobile layout foundation

## Build
Open this folder in Android Studio and let it sync Gradle. Then choose **Build > Build APK(s)**.

The repository intentionally does not include generated APKs or Gradle's downloaded distribution/cache.

## Current limitation
Chrome-only background/service-worker APIs (`chrome.alarms`, extension windows/tabs and the MV3 service worker) are stubbed for compatibility. The next Android-native pass should replace those with Android AlarmManager/WorkManager + notifications so task-end alerts and daily review notifications work reliably even when the app is closed.
