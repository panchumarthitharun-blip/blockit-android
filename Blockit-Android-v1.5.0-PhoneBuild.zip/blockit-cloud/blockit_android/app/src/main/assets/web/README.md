Blockit v1.4.6

Fix: clicking/selecting a task or periodic refresh no longer jumps the main calendar back to the top. The calendar scrollTop/scrollLeft are preserved across dashboard re-renders.


## v1.4.9 visual update
- Reduced calendar hour height from 180px to 120px.
- Reduced vertical calendar density while preserving time-aligned horizontal blocks.
- Increased task title/meta/preview note typography.
- Increased right-side task/day Notes editor font and line height.
- Preserved existing task/review/alarm/scroll behavior.


Editor persistence: dashboard auto-refresh/render is blocked while task/settings/review modals are open, preventing unsaved form fields from disappearing.
