# Blockit v1.5.0 — Complete Notes planner
let state, viewDate=new Date(), reviewOpen=false, selectedTaskId=null, completeNotesOpen=false;
const app=document.getElementById('app');
const pad=n=>String(n).padStart(2,'0');
const MINUTE_PX=2;
function dateKey(d=new Date()){return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`}
function addDays(key,n){const d=new Date(key+'T12:00:00');d.setDate(d.getDate()+n);return dateKey(d)}
function esc(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function timeToMinutes(t){const [h,m]=String(t||'00:00').split(':').map(Number);return h*60+m}
function minutesToTime(m){m=Math.max(0,Math.min(1439,m));return `${pad(Math.floor(m/60))}:${pad(m%60)}`}
function fmt(d){return d.toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric'})}
function isToday(){return dateKey(viewDate)===dateKey()}
function durationFor(t){return Math.max(1,timeToMinutes(t.end)-timeToMinutes(t.start))}
function blockSize(){return Math.max(5,Number(state.settings.defaultDuration)||15)}
function horizontalCount(){
 const mode=state.settings.horizontalBlockMode||'automatic';
 if(mode==='automatic') return Math.max(2,Math.min(12,Math.ceil(60/blockSize())));
 return Math.max(2,Math.min(12,Number(state.settings.horizontalBlockCount)||4));
}
function makeSegments(t){
 const start=timeToMinutes(t.start),end=timeToMinutes(t.end),total=Math.max(1,end-start),out=[];
 const count=horizontalCount();
 for(let i=0;i<count;i++){
  const a=start+total*i/count,b=start+total*(i+1)/count;
  out.push({i,start:Math.round(a),end:Math.round(b)});
 }
 return out;
}
function blockCount(t){return Math.max(1,Math.ceil(durationFor(t)/blockSize()))}
function overlapping(a,b){
 const as=timeToMinutes(a.start), ae=timeToMinutes(a.end), bs=timeToMinutes(b.start), be=timeToMinutes(b.end);
 return as < be && bs < ae;
}
function laneMap(tasks){
 const lanes=new Map(), ordered=[...tasks].sort((a,b)=>timeToMinutes(a.start)-timeToMinutes(b.start)||timeToMinutes(a.end)-timeToMinutes(b.end)||String(a.id).localeCompare(String(b.id)));
 const count=horizontalCount();
 for(const t of ordered){
  let lane=0;
  while(lane<count){
   const conflict=ordered.some(o=>o!==t && lanes.get(o.id)===lane && overlapping(t,o));
   if(!conflict) break;
   lane++;
  }
  lanes.set(t.id,Math.min(lane,count-1));
 }
 return lanes;
}
function gridMarkup(){
 const count=horizontalCount(), dur=blockSize();
 const widths=[]; for(let m=0;m<60;m+=dur) widths.push(Math.min(dur,60-m));
 const template=widths.map(w=>`${(w/60)*100}%`).join(' ');
 return `<div class="hourlines" style="--hcount:${count};--block-template:${template}">${Array.from({length:24},(_,h)=>`<div class="hourrow" data-hour="${h}" style="grid-template-columns:${template}">${widths.map((w,i)=>`<div class="slot" data-hour="${h}" data-slot="${i}" data-min="${Math.min(59,i*dur)}"></div>`).join('')}</div>`).join('')}</div>`;
}
function statusLabel(s){return ({planned:'Planned','in-progress':'In Progress',completed:'Completed',unfinished:'Unfinished',rolled_over:'Moved / Rolled Over',cancelled:'Cancelled'}[s]||'Planned')}
function statusClass(s){return String(s||'planned').replace('_','-')}
function effectiveStatus(t){if(t.status==='completed'||t.status==='unfinished'||t.status==='rolled_over'||t.status==='cancelled')return t.status; if(isToday()){const n=new Date().getHours()*60+new Date().getMinutes(),a=timeToMinutes(t.start),b=timeToMinutes(t.end);if(n>=b)return 'unfinished';if(n>=a)return 'in-progress'}return 'planned'}
function render(){
 // Never rebuild the dashboard while an editor/settings/review modal is open.
 // Rebuilding app.innerHTML destroys the modal and any unsaved text.
 if(document.getElementById('modal') || document.getElementById('settingsModal') || document.getElementById('reviewModal')) return;
 const previousMain=document.querySelector('.main');
 const savedScrollTop=previousMain?.scrollTop||0;
 const savedScrollLeft=previousMain?.scrollLeft||0;
 const d=dateKey(viewDate),dayTasks=state.tasks.filter(t=>t.date===d&&t.status!=='cancelled');
 const completed=dayTasks.filter(t=>t.status==='completed').length;
 currentLaneMap=laneMap(dayTasks);
 const unfinished=dayTasks.filter(t=>['unfinished','rolled_over'].includes(t.status)||effectiveStatus(t)==='unfinished').length;
 app.innerHTML=`<div class="top"><div class="brand"><span class="brandmark">●●</span> blockit <button class="completeNotesTop" id="completeNotes">Complete Notes</button></div>
 <div class="datepill"><button id="prev">‹</button><div><small>${isToday()?'TODAY':'DAY'}</small><b>${fmt(viewDate)}</b></div><button id="next">›</button><button id="today">Today</button></div>
 <div class="topright"><button class="reviewTop" id="review">End-of-Day Review${unfinished?` (${unfinished})`:''}</button><span class="live" id="live"></span><button id="opts">⚙</button></div></div>
 <div class="layout"><aside class="side"><div class="greet">Good ${new Date().getHours()<12?'Morning':new Date().getHours()<18?'Afternoon':'Evening'}!</div>
 <div class="summary"><b>${completed}/${dayTasks.length}</b> completed · <b>${unfinished}</b> need review</div><div class="section">Today's tasks</div><div id="taskList"></div>
 <div class="section">Inbox / unfinished</div><div id="inbox"></div><button class="new" id="new">＋ New Task</button></aside>
 <main class="main"><div class="daybar"><b>${fmt(viewDate)}</b><span>${dayTasks.length} scheduled · ${completed} completed · ${dayTasks.reduce((n,t)=>n+blockCount(t),0)} blocks</span></div>
 <div class="calendar"><div class="timecol">${Array.from({length:24},(_,h)=>`<div class="time">${h%12||12} ${h<12?'AM':'PM'}<span>▧</span></div>`).join('')}</div>
 <div class="daycanvas" id="daycanvas">${gridMarkup()}<div class="blocks">${dayTasks.map(renderBlock).join('')}</div></div></div></main>
 <aside class="notes">${(()=>{const selected=selectedTaskId?state.tasks.find(x=>x.id===selectedTaskId&&x.date===d):null; return selected?`<div class="notehead">Task Notes <span><button id="clearTaskNotes" class="miniBtn" title="Show day notes">Day</button></span></div><div class="notetime"><b>${esc(selected.title)}</b> · ${selected.start}–${selected.end}</div><textarea id="notes" placeholder="Add notes for this task…">${esc(selected.notes||'')}</textarea>`:`<div class="notehead">Notes <span>▣　♧　⚙</span></div><div class="notetime">Add notes for ${fmt(viewDate)}</div><textarea id="notes" placeholder="Add your notes here…">${esc(state.notes[d]||'')}</textarea>`})()}</aside></div>`;
 document.getElementById('prev').onclick=()=>{viewDate.setDate(viewDate.getDate()-1);render()};
 document.getElementById('next').onclick=()=>{viewDate.setDate(viewDate.getDate()+1);render()};
 document.getElementById('today').onclick=()=>{viewDate=new Date();render()};
 document.getElementById('review').onclick=()=>showReview(true);
 document.getElementById('completeNotes').onclick=()=>openCompleteNotes();
 document.getElementById('opts').onclick=()=>openSettings();
 document.getElementById('new').onclick=()=>openEditor(null,d,`${pad(new Date().getHours())}:00`);
 const notesEl=document.getElementById('notes');
 const selectedForNotes=selectedTaskId?state.tasks.find(x=>x.id===selectedTaskId&&x.date===d):null;
 notesEl.oninput=async e=>{if(selectedForNotes){selectedForNotes.notes=e.target.value}else{state.notes[d]=e.target.value}await saveState(state)};
 document.getElementById('clearTaskNotes')?.addEventListener('click',()=>{selectedTaskId=null;render()});
 document.querySelectorAll('.slot').forEach(c=>c.onclick=()=>openEditor(null,d,`${pad(Number(c.dataset.hour))}:${pad(Math.min(59,Number(c.dataset.slot)*blockSize()))}`));
 document.querySelectorAll('.block').forEach(b=>b.onclick=e=>{e.preventDefault();e.stopPropagation();selectedTaskId=b.dataset.id;openEditor(b.dataset.id)});
 const newMain=document.querySelector('.main');
 if(newMain){newMain.scrollTop=savedScrollTop;newMain.scrollLeft=savedScrollLeft;}
 document.querySelectorAll('.taskitem [data-edit]').forEach(b=>b.onclick=e=>{e.stopPropagation();selectedTaskId=b.dataset.edit;openEditor(b.dataset.edit)});
 renderTasks(dayTasks);renderInbox();addNowLine();updateLive();
}
let currentLaneMap=new Map();
function renderBlock(t){
 const start=timeToMinutes(t.start), duration=durationFor(t), end=Math.min(1440,start+duration), status=effectiveStatus(t);
 const progress=isToday()&&['planned','in-progress'].includes(status)?progressFor(start,end):status==='completed'?100:0;
 const rowH=120, padY=6;
 const slice=state.settings.horizontalBlockMode==='fixed'
   ? 60/horizontalCount()
   : blockSize();
 const colsPerHour=Math.max(1,Math.ceil(60/slice));
 const blocks=[];
 let cursor=start;
 while(cursor<end){
   const hour=Math.floor(cursor/60);
   const hourEnd=Math.min(end,(hour+1)*60);
   const hourBase=hour*60;
   const localStart=cursor-hourBase;
   const localEnd=hourEnd-hourBase;
   const firstCol=Math.max(0,Math.min(colsPerHour-1,Math.floor(localStart/slice)));
   const lastCol=Math.max(firstCol,Math.min(colsPerHour-1,Math.ceil(localEnd/slice)-1));
   const colStartPct=(firstCol/colsPerHour)*100;
   const colEndPct=((lastCol+1)/colsPerHour)*100;
   blocks.push({hour,left:colStartPct,width:Math.max(1,colEndPct-colStartPct),first:blocks.length===0});
   cursor=hourEnd;
 }
 const laneIndex=currentLaneMap.get(t.id)||0;
 const overlappingTasks=state.tasks.filter(x=>x.id!==t.id&&x.date===t.date&&x.status!=='cancelled'&&overlapping(t,x));
 const laneCount=Math.max(1,Math.min(horizontalCount(),1+overlappingTasks.filter(x=>(currentLaneMap.get(x.id)||0)===laneIndex).length));
 const laneGap=5;
 const laneH=(rowH-padY*2-laneGap*(laneCount-1))/laneCount;
 const topOffset=padY+laneIndex*(laneH+laneGap);
 const title=esc(t.title||'Untitled task');
 const meta=`${minutesToTime(start)}–${minutesToTime(end)} · ${blockCount(t)} blocks`;
 return blocks.map(seg=>`<div class="block ${statusClass(status)} time-slot-task" data-id="${t.id}" title="${title} — ${minutesToTime(start)}–${minutesToTime(end)}" style="top:${seg.hour*rowH+topOffset}px;left:${seg.left}%;width:calc(${seg.width}% - 4px);height:${Math.max(28,laneH)}px;z-index:${10+(laneIndex||0)}">
   <div class="taskCardProgress" style="width:${progress}%"></div>
   <div class="taskCardTitle">${title}</div>
   <div class="taskCardMeta">${meta}</div>
   ${t.notes?`<div class="taskCardNotes">📝 ${esc(t.notes).replace(/\s+/g,' ').trim()}</div>`:''}
   <span class="statusBadge ${statusClass(status)}">${statusLabel(status)}</span>
 </div>`).join('');
}
function progressFor(a,b){const n=new Date().getHours()*60+new Date().getMinutes();if(n<=a)return 0;if(n>=b)return 100;return (n-a)/(b-a)*100}
function segmentProgress(s){const n=new Date().getHours()*60+new Date().getMinutes();if(n<=s.start)return 0;if(n>=s.end)return 100;return (n-s.start)/(s.end-s.start)*100}
function renderTasks(xs){
 const el=document.getElementById('taskList');
 el.innerHTML=xs.length?xs.map(t=>{const s=effectiveStatus(t);return `<div class="taskitem"><input type="checkbox" data-check="${t.id}" ${t.status==='completed'?'checked':''}><div class="tasktext"><b class="${t.status==='completed'?'done':''}">${esc(t.title)}</b><small>${t.start}–${t.end} · ${blockCount(t)} blocks</small><span class="miniStatus ${statusClass(s)}">${statusLabel(s)}</span></div><button data-edit="${t.id}">⋮</button></div>`}).join(''):'<div class="empty">No tasks scheduled.</div>';
 el.querySelectorAll('[data-check]').forEach(c=>c.onchange=async()=>{const t=state.tasks.find(x=>x.id===c.dataset.check);if(t){t.status=c.checked?'completed':'planned';await saveState(state);render()}});
 el.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>openEditor(b.dataset.edit));
}
function renderInbox(){const el=document.getElementById('inbox'),xs=state.tasks.filter(t=>['unfinished','rolled_over'].includes(t.status)||!t.date);el.innerHTML=xs.length?xs.map(t=>`<div class="taskitem compact" data-edit2="${t.id}"><b>${esc(t.title)}</b><small>${t.date||'Inbox'}</small><span class="miniStatus ${statusClass(t.status)}">${statusLabel(t.status)}</span></div>`).join(''):'<div class="empty">Nothing waiting.</div>';el.querySelectorAll('[data-edit2]').forEach(b=>b.onclick=()=>openEditor(b.dataset.edit2))}
function addNowLine(){if(!isToday())return;const canvas=document.getElementById('daycanvas');if(!canvas)return;const n=new Date(),line=document.createElement('div');line.className='nowline';line.style.top=`${(n.getHours()*60+n.getMinutes())*MINUTE_PX}px`;canvas.appendChild(line)}
function updateLive(){const e=document.getElementById('live');if(e)e.textContent=new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});setTimeout(updateLive,30000)}
function openEditor(id,date,start){
 const t=id?state.tasks.find(x=>x.id===id):null;const d=t||{title:'',date:date||dateKey(),start:start||'09:00',end:minutesToTime(timeToMinutes(start||'09:00')+blockSize()),notes:'',priority:'Normal',status:'planned',alarm:true,repeatEveryDay:false};
 app.insertAdjacentHTML('beforeend',`<div class="modal" id="modal"><div class="card"><div class="modalhead"><h2>${t?'Edit task':'New task'}</h2><button id="close">×</button></div><div class="field"><label>Task</label><input id="fTitle" value="${esc(d.title)}" autofocus></div><div class="row"><div class="field"><label>Date</label><input id="fDate" type="date" value="${d.date}"></div><div class="field"><label>Status</label><select id="fStatus"><option value="planned">Planned</option><option value="in-progress">In Progress</option><option value="completed">Completed</option><option value="unfinished">Unfinished</option><option value="rolled_over">Moved / Rolled Over</option><option value="cancelled">Cancelled</option></select></div></div><div class="row"><div class="field"><label>Start</label><input id="fStart" type="time" value="${d.start}"></div><div class="field"><label>End</label><input id="fEnd" type="time" value="${d.end}"></div></div><div class="info">Horizontal layout: <b>${state.settings.horizontalBlockMode==='fixed'?`${state.settings.horizontalBlockCount} equal blocks`:`${blockSize()}-minute blocks`}</b>.</div><div class="toggleRow"><label><input id="fRepeat" type="checkbox" ${d.repeatEveryDay?'checked':''}> 🔁 Repeat every day</label><span>Same time on each day</span></div><div class="toggleRow"><label><input id="fAlarm" type="checkbox" ${d.alarm!==false?'checked':''}> 🔔 Notify when each block ends</label></div><div class="field"><label>Notes</label><textarea id="fNotes">${esc(d.notes||'')}</textarea></div><div class="actions"><button id="cancel">Cancel</button>${t?'<button id="delete" class="danger">Delete</button>':''}<button id="save" class="primary">Save</button></div></div></div>`);
 document.getElementById('fStatus').value=d.status||'planned';const close=()=>document.getElementById('modal')?.remove();document.getElementById('close').onclick=close;document.getElementById('cancel').onclick=close;
 document.getElementById('save').onclick=async()=>{
  const title=document.getElementById('fTitle').value.trim()||'Untitled task',date=document.getElementById('fDate').value,start=document.getElementById('fStart').value,end=document.getElementById('fEnd').value;
  if(timeToMinutes(end)<=timeToMinutes(start)){alert('End time must be after start time.');return}
  const repeat=document.getElementById('fRepeat').checked;
  const seriesId=t?.recurrenceSeriesId||t?.id||uid('series');
  const base={...(t||{id:uid('task'),createdAt:new Date().toISOString()}),title,date,start,end,notes:document.getElementById('fNotes').value,priority:'Normal',status:document.getElementById('fStatus').value,alarm:document.getElementById('fAlarm').checked,repeatEveryDay:repeat,blockDuration:blockSize(),recurrenceSeriesId:repeat?seriesId:undefined};
  if(t){
    const series=state.tasks.filter(x=>x.recurrenceSeriesId===seriesId||x.id===seriesId);
    state.tasks=state.tasks.map(x=>x.id===t.id?base:x);
    if(repeat){
      const existingDates=new Set(state.tasks.filter(x=>x.recurrenceSeriesId===seriesId).map(x=>x.date));
      for(let i=1;i<=365;i++){const dd=addDays(date,i);if(!existingDates.has(dd))state.tasks.push({...base,id:uid('task'),date:dd,status:'planned',createdAt:base.createdAt,recurrenceSeriesId:seriesId});}
    }else{
      state.tasks=state.tasks.filter(x=>!(x.recurrenceSeriesId===seriesId&&x.id!==base.id));
    }
  }else{
    state.tasks.push(base);
    if(repeat)for(let i=1;i<=365;i++)state.tasks.push({...base,id:uid('task'),date:addDays(date,i),status:'planned',recurrenceSeriesId:seriesId});
  }
  await saveState(state);selectedTaskId=base.id;close();render();
 };
 if(t)document.getElementById('delete').onclick=async()=>{state.tasks=state.tasks.filter(x=>x.id!==t.id&&x.recurrenceParent!==t.id);await saveState(state);close();render()}
}
function openCompleteNotes(){
 if(completeNotesOpen)return;
 completeNotesOpen=true;
 const d=dateKey(viewDate), saved=state.completeNotes?.[d]||{};
 const todo=Array.from({length:4},(_,i)=>saved.todo?.[i]||{text:'',done:false});
 const daily=Array.from({length:5},(_,i)=>saved.daily?.[i]||{text:'',done:false});
 const calls=saved.calls||'';
 const highlights=saved.highlights||'';
 const priority=saved.priority||'';
 const accomplished=saved.accomplished||'';
 const slots=[]; const start=timeToMinutes(state.settings.workingStart||'08:00'), end=timeToMinutes(state.settings.workingEnd||'22:00');
 for(let t=start;t<end;t+=60) slots.push(minutesToTime(t)+'–'+minutesToTime(Math.min(t+60,end)));
 const schedule=saved.schedule||{};
 const modal=document.createElement('div'); modal.className='modal completeNotesModal'; modal.id='completeNotesModal';
 modal.innerHTML=`<div class="card completeNotesCard">
 <div class="modalhead"><div><h2>Complete Notes</h2><p class="sub">Daily planning and reflection for ${esc(fmt(viewDate))}.</p></div><button id="closeCompleteNotes">×</button></div>
 <div class="cnTop"><div><label>Date</label><input id="cnDate" type="date" value="${d}"></div><div class="cnHighlight"><label>Daily Highlights</label><input id="cnHighlights" value="${esc(highlights)}" placeholder="What was the highlight of the day?"></div><div><label>Priority of the day</label><select id="cnPriority"><option value="">Select</option><option value="1" ${priority==='1'?'selected':''}>1</option><option value="2" ${priority==='2'?'selected':''}>2</option><option value="3" ${priority==='3'?'selected':''}>3</option><option value="4" ${priority==='4'?'selected':''}>4</option><option value="5" ${priority==='5'?'selected':''}>5</option></select></div><div><label>Feel accomplished?</label><select id="cnAccomplished"><option value="" ${!accomplished?'selected':''}>Select</option><option value="Yes" ${accomplished==='Yes'?'selected':''}>Yes</option><option value="No" ${accomplished==='No'?'selected':''}>No</option></select></div></div>
 <div class="cnGrid">
  <section class="cnSection"><h3>To Do <span>Only 4 simple tasks</span></h3><div class="cnTodo">${todo.map((x,i)=>`<div class="cnCheckRow"><span>${i+1}</span><input class="cnTodoText" data-i="${i}" value="${esc(x.text)}" placeholder="Simple task ${i+1}"><input type="checkbox" class="cnTodoDone" data-i="${i}" ${x.done?'checked':''}></div>`).join('')}</div></section>
  <section class="cnSection callsSection"><h3>Calls <span>list</span></h3><textarea id="cnCalls" placeholder="Names, calls, follow-ups…">${esc(calls)}</textarea></section>
 </div>
 <section class="cnSection cnSchedule"><h3>Scheduling <span>Time blocks • ${blockSize()} min</span></h3><div class="cnScheduleGrid">${slots.map((slot,i)=>{const val=schedule[i]||'';return `<label class="cnSlot"><b>${slot}</b><input class="cnScheduleInput" data-i="${i}" value="${esc(val)}" placeholder="What will you do?"></label>`}).join('')}</div></section>
 <section class="cnSection cnDaily"><h3>Daily <span>Everyday</span></h3><div class="cnDailyList">${daily.map((x,i)=>`<div class="cnCheckRow"><span>${i+1}</span><input class="cnDailyText" data-i="${i}" value="${esc(x.text)}" placeholder="Everyday task ${i+1}"><input type="checkbox" class="cnDailyDone" data-i="${i}" ${x.done?'checked':''}></div>`).join('')}</div></section>
 <div class="cnFooter"><span id="cnSaved">Saved for ${esc(fmt(viewDate))}</span><button id="cancelCompleteNotes">Cancel</button><button id="saveCompleteNotes" class="primary">Save Complete Notes</button></div>
 </div>`;
 document.body.appendChild(modal);
 const close=()=>{modal.remove();completeNotesOpen=false};
 modal.querySelector('#closeCompleteNotes').onclick=close; modal.querySelector('#cancelCompleteNotes').onclick=close;
 modal.querySelector('#cnDate').onchange=e=>{ if(e.target.value && e.target.value!==d){ viewDate=new Date(e.target.value+'T12:00:00'); close(); render(); setTimeout(openCompleteNotes,0); }};
 modal.querySelector('#saveCompleteNotes').onclick=async()=>{
   const obj={highlights:modal.querySelector('#cnHighlights').value,priority:modal.querySelector('#cnPriority').value,accomplished:modal.querySelector('#cnAccomplished').value,calls:modal.querySelector('#cnCalls').value,todo:todo.map((x,i)=>({text:modal.querySelector(`.cnTodoText[data-i="${i}"]`).value,done:modal.querySelector(`.cnTodoDone[data-i="${i}"]`).checked})),daily:daily.map((x,i)=>({text:modal.querySelector(`.cnDailyText[data-i="${i}"]`).value,done:modal.querySelector(`.cnDailyDone[data-i="${i}"]`).checked})),schedule:{}};
   modal.querySelectorAll('.cnScheduleInput').forEach(el=>obj.schedule[el.dataset.i]=el.value);
   state.completeNotes=state.completeNotes||{}; state.completeNotes[d]=obj; await saveState(state); modal.querySelector('#cnSaved').textContent='Saved just now';
 };
}
function openSettings(){
 const st=state.settings||{};
 const modal=document.createElement('div'); modal.className='modal'; modal.id='settingsModal';
 modal.innerHTML=`<div class="card settingsCard"><div class="modalhead"><div><h2>Settings</h2><p class="sub">Configure alarms, block layout and the end-of-day review.</p></div><button id="closeSettings">×</button></div>
 <div class="settingsSection"><h3>Alarms & Notifications</h3>
 <div class="settingsRow"><div><b>Browser notifications</b><span>Show a notification when a block/task ends.</span></div><input id="sNotifications" type="checkbox" ${st.notifications!==false?'checked':''}></div>
 <div class="settingsRow"><div><b>Alarm sound</b><span>Play an alarm/chime when a block ends.</span></div><input id="sSound" type="checkbox" ${st.sound!==false?'checked':''}></div>
 <div class="settingsRow"><div><b>Popup after every task</b><span>Show an in-page popup when the final block of a task ends.</span></div><input id="sPopup" type="checkbox" ${st.taskPopup!==false?'checked':''}></div>
 </div>
 <div class="settingsSection"><h3>End-of-Day Review</h3>
 <div class="settingsRow"><div><b>Daily end-of-day review</b><span>Automatically open the review board at the configured time.</span></div><input id="sDaily" type="checkbox" ${st.dailyReview!==false?'checked':''}></div>
 <div class="settingsRow"><div><b>Review time</b><span>When the automatic review should appear.</span></div><input id="sReviewTime" type="time" value="${esc(st.dailyReviewTime||'21:00')}"></div>
 </div>
 <div class="settingsSection"><h3>Horizontal Blocks</h3>
 <div class="settingsRow"><div><b>Horizontal block mode</b><span>Automatic uses the Default block duration to divide each hour.</span></div><select id="sMode"><option value="automatic" ${(st.horizontalBlockMode||'automatic')==='automatic'?'selected':''}>Automatic (by duration)</option><option value="fixed" ${(st.horizontalBlockMode||'automatic')==='fixed'?'selected':''}>Fixed number</option></select></div>
 <div class="settingsRow"><div><b>Number of horizontal blocks</b><span>Used only when Fixed number is selected.</span></div><select id="sCount">${Array.from({length:11},(_,i)=>i+2).map(n=>`<option value="${n}" ${Number(st.horizontalBlockCount||4)===n?'selected':''}>${n} blocks</option>`).join('')}</select></div>
 <div class="settingsRow"><div><b>Default block duration</b><span>Default duration for new tasks.</span></div><input id="sDuration" type="number" min="5" max="240" step="5" value="${Math.max(5,Number(st.defaultDuration)||15)}"></div>
 </div>
 <div class="settingsSection"><h3>Working Hours</h3><div class="settingsRow"><div><b>Working hours</b><span>Used for planning context.</span></div><div class="timePair"><input id="sStart" type="time" value="${esc(st.workingStart||'08:00')}"><span>–</span><input id="sEnd" type="time" value="${esc(st.workingEnd||'22:00')}"></div></div></div>
 <div class="settingsActions"><button id="resetData" class="dangerBtn">Reset data</button><span id="settingsMsg"></span><button id="cancelSettings">Cancel</button><button id="saveSettings" class="primary">Save settings</button></div></div>`;
 document.body.appendChild(modal);
 const close=()=>modal.remove();
 modal.querySelector('#closeSettings').onclick=close; modal.querySelector('#cancelSettings').onclick=close;
 modal.querySelector('#resetData').onclick=async()=>{if(confirm('Delete all Blockit tasks and notes?')){state.tasks=[];state.notes={};state.lastReviewDate='';await saveState(state);close();render()}};
 modal.querySelector('#saveSettings').onclick=async()=>{
   state.settings.notifications=modal.querySelector('#sNotifications').checked;
   state.settings.sound=modal.querySelector('#sSound').checked;
   state.settings.taskPopup=modal.querySelector('#sPopup').checked;
   state.settings.dailyReview=modal.querySelector('#sDaily').checked;
   state.settings.dailyReviewTime=modal.querySelector('#sReviewTime').value||'21:00';
   state.settings.horizontalBlockCount=Math.max(2,Math.min(12,Number(modal.querySelector('#sCount').value)||4));
   state.settings.horizontalBlockMode=modal.querySelector('#sMode').value;
   state.settings.defaultDuration=Math.max(5,Math.min(240,Number(modal.querySelector('#sDuration').value)||15));
   state.settings.workingStart=modal.querySelector('#sStart').value||'08:00'; state.settings.workingEnd=modal.querySelector('#sEnd').value||'22:00';
   await saveState(state); close(); render();
 };
}
function playAlarm(){try{const C=window.AudioContext||window.webkitAudioContext;if(!C)return;const c=new C();const o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.setValueAtTime(880,c.currentTime);o.frequency.exponentialRampToValueAtTime(440,c.currentTime+.45);g.gain.setValueAtTime(.0001,c.currentTime);g.gain.exponentialRampToValueAtTime(.22,c.currentTime+.02);g.gain.exponentialRampToValueAtTime(.0001,c.currentTime+.55);o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+.6);setTimeout(()=>c.close(),800)}catch(e){}}
function showBlockEndPopup(data){
 if(!state)return;
 if(state.settings.sound!==false)playAlarm();
 if(!state.settings.taskPopup||!data.final)return;
 const old=document.getElementById('blockEndPopup'); if(old)old.remove();
 const m=document.createElement('div');m.className='modal';m.id='blockEndPopup';
 m.innerHTML=`<div class="card alarmCard"><div class="alarmIcon">⏰</div><h2>${data.final?'Task ended':'Block ended'}</h2><p class="alarmTask">${esc(data.title||'Task')}</p><p class="alarmTime">${esc(data.start||'')} – ${esc(data.end||'')}</p><div class="alarmStatus">${data.final?'This task has reached its end.':'The current block has ended.'}</div><div class="actions"><button id="alarmSnooze">Snooze 5 min</button><button id="alarmReview">Review</button><button id="alarmDone" class="primary">${data.final?'Mark complete':'Close'}</button></div></div>`;
 document.body.appendChild(m);
 m.querySelector('#alarmDone').onclick=async()=>{if(data.final){const t=state.tasks.find(x=>x.id===data.id);if(t){t.status='completed';await saveState(state);render()}}m.remove()};
 m.querySelector('#alarmReview').onclick=()=>{m.remove();showReview(true)};
 m.querySelector('#alarmSnooze').onclick=()=>{m.remove();setTimeout(()=>showBlockEndPopup({...data,final:false,start:data.end,end:minutesToTime(timeToMinutes(data.end)+5)}),300000)};
}
if(chrome?.runtime?.onMessage)chrome.runtime.onMessage.addListener(msg=>{if(msg?.type==='blockit-block-end'){showBlockEndPopup(msg)}});

function reviewItems(includeAllToday=false){
 const today=dateKey();
 const now=new Date().getHours()*60+new Date().getMinutes();
 return state.tasks.filter(t=>{
  if(t.status==='completed'||t.status==='cancelled') return false;
  // Manual review: show every incomplete task scheduled for the selected day,
  // plus anything already in the unfinished/rollover inbox.
  if(includeAllToday) return t.date===today || t.status==='unfinished' || t.status==='rolled_over';
  // Automatic review: only tasks whose scheduled end time has passed,
  // plus tasks already explicitly marked unfinished/rolled over.
  return (t.date===today&&t.end&&timeToMinutes(t.end)<=now)||t.status==='unfinished'||t.status==='rolled_over';
 });
}
async function showReview(manual=false){if(reviewOpen)return;reviewOpen=true;const xs=reviewItems(manual),modal=document.createElement('div');modal.className='modal reviewModal';modal.innerHTML=`<div class="card reviewCard"><div class="modalhead"><div><h2>End-of-Day Review Board</h2><p class="sub">Choose one action for each incomplete task. Select an action for every task before finishing the review.</p></div><button id="closeReview">×</button></div><div class="reviewStats"><span>To review: <b>${xs.length}</b></span><span>Completed today: <b>${state.tasks.filter(t=>t.date===dateKey()&&t.status==='completed').length}</b></span></div><div class="reviewList">${xs.length?xs.map(t=>`<div class="reviewItem" data-id="${t.id}"><div class="reviewTitle"><div><b>${esc(t.title)}</b><span>${t.date||'Inbox'} · ${t.start||''}–${t.end||''} · ${blockCount(t)} blocks</span></div><span class="reviewStatus ${statusClass(effectiveStatus(t))}">${statusLabel(effectiveStatus(t))}</span></div><div class="reviewChoices"><label class="choice"><input type="checkbox" class="reviewCheck" value="tomorrow"> Move to next day</label><label class="choice"><input type="checkbox" class="reviewCheck" value="custom"> Move to custom date</label><input class="customDate" type="date" min="${dateKey()}" value="${addDays(dateKey(),1)}" disabled><label class="choice"><input type="checkbox" class="reviewCheck" value="inbox"> Keep in Inbox</label><label class="choice"><input type="checkbox" class="reviewCheck" value="complete"> Mark complete</label></div><div class="reviewActions"><button class="applyReview primary">Apply</button><button class="deleteReview danger">Delete</button></div></div>`).join(''):'<div class="allClear"><div>✓</div><b>All clear</b><span>No unfinished tasks need review.</span></div>'}</div><div class="reviewFooter"><span>${xs.length} item${xs.length===1?'':'s'} to review</span><button id="finishReview" class="primary">Finish Review</button></div></div>`;document.body.appendChild(modal);
 modal.querySelector('#closeReview').onclick=()=>{modal.remove();reviewOpen=false};modal.querySelectorAll('.reviewItem').forEach(item=>{const custom=item.querySelector('.customDate');const checks=[...item.querySelectorAll('.reviewCheck')];
checks.forEach(ch=>ch.onchange=()=>{
 if(ch.checked)checks.forEach(other=>{if(other!==ch)other.checked=false});
 custom.disabled=!item.querySelector('.reviewCheck[value="custom"]').checked;
});item.querySelector('.applyReview').onclick=async()=>{const t=state.tasks.find(x=>x.id===item.dataset.id),action=item.querySelector('.reviewCheck:checked')?.value;if(!t||!action){alert('Choose an action first.');return}if(action==='complete'){t.status='completed'}if(action==='tomorrow'){t.status='rolled_over';t.date=addDays(dateKey(),1);t.rolloverCount=(t.rolloverCount||0)+1}if(action==='custom'){if(!custom.value){alert('Choose a custom date.');return}t.status='rolled_over';t.date=custom.value;t.rolloverCount=(t.rolloverCount||0)+1}if(action==='inbox'){t.status='unfinished';t.date=''}await saveState(state);item.remove();render();if(!document.body.contains(modal))return;if(!reviewItems().length){modal.querySelector('.reviewList').innerHTML='<div class="allClear"><div>✓</div><b>All clear</b><span>Everything has been handled.</span></div>'}};item.querySelector('.deleteReview').onclick=async()=>{state.tasks=state.tasks.filter(x=>x.id!==item.dataset.id);await saveState(state);item.remove();render()}});modal.querySelector('#finishReview').onclick=async()=>{state.lastReviewDate=dateKey();await saveState(state);modal.remove();reviewOpen=false;render()}}
function maybeAutoReview(){if(!state.settings.dailyReview||!isToday()||state.lastReviewDate===dateKey())return;const [h,m]=state.settings.dailyReviewTime.split(':').map(Number),now=new Date();if(now.getHours()*60+now.getMinutes()>=h*60+m&&reviewItems().length)setTimeout(()=>showReview(),250)}
getState().then(s=>{state=s;render();maybeAutoReview();if(location.hash==='#new')setTimeout(()=>openEditor(),100);if(location.hash==='#review')setTimeout(()=>showReview(),100)});
setInterval(()=>{if(state&&!reviewOpen && !document.getElementById('modal') && !document.getElementById('settingsModal') && !document.getElementById('completeNotesModal')){render();maybeAutoReview()}},60000);
