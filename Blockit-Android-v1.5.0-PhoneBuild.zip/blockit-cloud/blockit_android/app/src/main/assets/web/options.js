getState().then(s=>{
  for(const k of ['notifications','sound','taskPopup','dailyReview']) document.getElementById(k).checked=!!s.settings[k];
  for(const k of ['dailyReviewTime','workingStart','workingEnd']) document.getElementById(k).value=s.settings[k]||'';
  document.getElementById('defaultDuration').value=Math.max(5,Number(s.settings.defaultDuration)||15);
  document.getElementById('horizontalBlockCount').value=Math.max(2,Math.min(12,Number(s.settings.horizontalBlockCount)||4));

  document.getElementById('save').onclick=async()=>{
    for(const k of ['notifications','sound','taskPopup','dailyReview']) s.settings[k]=document.getElementById(k).checked;
    for(const k of ['dailyReviewTime','workingStart','workingEnd']) s.settings[k]=document.getElementById(k).value;
    s.settings.defaultDuration=Math.max(5,Math.min(240,Number(document.getElementById('defaultDuration').value)||15));
    s.settings.horizontalBlockCount=Math.max(2,Math.min(12,Number(document.getElementById('horizontalBlockCount').value)||4));
    s.settings.horizontalBlockMode='fixed';
    await saveState(s);
    document.getElementById('msg').textContent=`Saved. Calendar now uses ${s.settings.horizontalBlockCount} horizontal blocks per hour.`;
  };

  document.getElementById('reset').onclick=async()=>{
    if(confirm('Delete all Blockit tasks and notes?')){
      s.tasks=[];s.notes={};s.lastReviewDate='';
      await saveState(s);
      document.getElementById('msg').textContent='Data cleared.';
    }
  };
});
