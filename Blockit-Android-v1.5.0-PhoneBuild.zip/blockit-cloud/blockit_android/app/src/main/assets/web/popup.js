document.addEventListener('DOMContentLoaded', async () => {
  const summary = document.getElementById('summary');
  const open = document.getElementById('open');
  const newBtn = document.getElementById('new');
  const settings = document.getElementById('settings');
  try {
    const {tasks} = await getState();
    const d = dateKey();
    const today = tasks.filter(t => t.date === d);
    const done = today.filter(t => t.status === 'completed').length;
    summary.textContent = `Today: ${done}/${today.length} completed`;
  } catch (e) { summary.textContent = 'Ready'; }
  open.addEventListener('click', () => chrome.tabs.create({url: chrome.runtime.getURL('dashboard.html')}));
  newBtn.addEventListener('click', () => chrome.tabs.create({url: chrome.runtime.getURL('dashboard.html#new')}));
  settings.addEventListener('click', () => chrome.runtime.openOptionsPage());
});
