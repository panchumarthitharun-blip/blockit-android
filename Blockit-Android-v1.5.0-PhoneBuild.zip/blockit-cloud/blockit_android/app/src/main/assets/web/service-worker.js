importScripts('storage.js');

async function clearTaskAlarms(taskId){
  const alarms = await chrome.alarms.getAll();
  for (const a of alarms) {
    if (a.name.startsWith('blockseg_'+taskId+'_')) await chrome.alarms.clear(a.name);
  }
}

async function scheduleTaskAlarms(task){
  await clearTaskAlarms(task.id);
  if(!task || task.status==='completed' || task.status==='cancelled' || task.alarm===false) return;
  const start=timeToMinutes(task.start), end=timeToMinutes(task.end);
  const duration=Math.max(1, end-start);
  const state=await getState();
  const segments=[];
  if((state.settings.horizontalBlockMode||'duration')==='fixed'){
    const count=Math.max(2,Math.min(12,Number(state.settings.horizontalBlockCount)||4)),total=end-start;
    for(let i=0;i<count;i++)segments.push({start:Math.round(start+total*i/count),end:Math.round(start+total*(i+1)/count)});
  }else{
    const size=Math.max(1,Number(state.settings.defaultDuration)||20);
    for(let cursor=start;cursor<end;cursor+=size)segments.push({start:cursor,end:Math.min(cursor+size,end)});
  }
  for(let index=0;index<segments.length;index++){
    const segmentEnd=segments[index].end;
    const endAt=new Date(`${task.date}T${minutesToTime(segmentEnd)}:00`).getTime();
    if(endAt>Date.now())await chrome.alarms.create(`blockseg_${task.id}_${index}`,{when:endAt});
  }
}

async function scheduleAll(){
  const state=await getState();
  for(const t of state.tasks) await scheduleTaskAlarms(t);
  await scheduleDaily();
}

async function scheduleDaily(){
  const {settings}=await getState();
  await chrome.alarms.clear('daily_review');
  if(!settings.dailyReview) return;
  const [h,m]=settings.dailyReviewTime.split(':').map(Number);
  const now=new Date(); const next=new Date();
  next.setHours(h,m,0,0);
  if(next<=now) next.setDate(next.getDate()+1);
  await chrome.alarms.create('daily_review',{when:next.getTime(),periodInMinutes:1440});
}

chrome.runtime.onInstalled.addListener(async()=>{
  const state=await getState();
  await saveState(state);
  await scheduleAll();
});
chrome.runtime.onStartup.addListener(scheduleAll);

chrome.commands.onCommand.addListener(cmd=>{
  if(cmd==='new-task') chrome.tabs.create({url:chrome.runtime.getURL('dashboard.html#new')});
});

chrome.storage.onChanged.addListener(async(changes, area)=>{
  if(area!=='local') return;
  if(changes.tasks) {
    const oldTasks=changes.tasks.oldValue||[], newTasks=changes.tasks.newValue||[];
    const ids=new Set([...oldTasks,...newTasks].map(t=>t.id));
    for(const id of ids){
      const t=newTasks.find(x=>x.id===id);
      if(t) await scheduleTaskAlarms(t); else await clearTaskAlarms(id);
    }
  }
  if(changes.settings) await scheduleDaily();
});


async function openTaskEndWindow(payload, settings){
  if(settings.taskPopup===false) return;
  const q=new URLSearchParams({
    id:payload.id||'',
    title:payload.title||'Task',
    start:payload.start||'',
    end:payload.end||'',
    final:payload.final?'1':'0',
    sound:settings.sound!==false?'1':'0'
  });
  try{
    await chrome.windows.create({
      url:chrome.runtime.getURL(`alarm.html?${q.toString()}`),
      type:'popup',
      width:460,
      height:500,
      focused:true
    });
  }catch(e){ console.error('Blockit alarm window',e); }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse)=>{
  (async()=>{
    if(msg?.type!=='blockit-alarm-action') return;
    const state=await getState();
    const t=state.tasks.find(x=>x.id===msg.id);
    if(!t) return;
    if(msg.action==='complete'){
      t.status='completed'; t.completedAt=new Date().toISOString();
      await saveState(state);
    } else if(msg.action==='snooze'){
      const mins=Math.max(1,Math.min(120,Number(msg.minutes)||5));
      const at=Date.now()+mins*60000;
      await chrome.alarms.create(`snooze_${t.id}_${Date.now()}`,{when:at});
      await chrome.storage.local.set({['snooze_'+t.id]:{title:t.title,id:t.id,minutes:mins}});
    } else if(msg.action==='review'){
      await chrome.tabs.create({url:chrome.runtime.getURL('dashboard.html#review')});
    }
    if(sender.tab?.windowId) { try{ await chrome.windows.remove(sender.tab.windowId); }catch(e){} }
    sendResponse({ok:true});
  })();
  return true;
});

chrome.alarms.onAlarm.addListener(async alarm=>{
  const state=await getState();
  const {tasks,settings}=state;
  if(alarm.name==='daily_review'){
    if(settings.notifications){
      chrome.notifications.create('daily_review',{
        type:'basic',iconUrl:'assets/icon128.png',requireInteraction:true,priority:2,
        title:'Blockit — End-of-Day Review',
        message:'Your review board is ready. Decide what to do with unfinished tasks.'
      });
    }
    return;
  }
  if(alarm.name.startsWith('snooze_')){
    const id=alarm.name.slice('snooze_'.length).split('_').slice(0,-1).join('_');
    const data=(await chrome.storage.local.get('snooze_'+id))['snooze_'+id];
    if(data && settings.notifications){
      await chrome.notifications.create('snooze_'+id,{type:'basic',iconUrl:'assets/icon128.png',requireInteraction:true,priority:2,title:'Blockit — Snooze ended',message:`${data.title}: snooze period finished.`});
    }
    if(data) await chrome.storage.local.remove('snooze_'+id);
    if(data) await openTaskEndWindow({id:data.id,title:data.title,start:'Snooze',end:`+${data.minutes} min`,final:false},settings);
    return;
  }
  if(!alarm.name.startsWith('blockseg_')) return;
  const parts=alarm.name.split('_');
  const index=Number(parts.pop());
  const id=parts.slice(1).join('_');
  const t=tasks.find(x=>x.id===id);
  if(!t || t.status==='completed' || t.status==='cancelled') return;

  const start=timeToMinutes(t.start), end=timeToMinutes(t.end);
  let segmentStart,segmentEnd;
  if((settings.horizontalBlockMode||'duration')==='fixed'){
    const count=Math.max(2,Math.min(12,Number(settings.horizontalBlockCount)||4));
    segmentStart=Math.round(start+(end-start)*index/count);
    segmentEnd=Math.round(start+(end-start)*(index+1)/count);
  }else{
    const size=Math.max(1,Number(settings.defaultDuration)||20);
    segmentStart=start+index*size;
    segmentEnd=Math.min(segmentStart+size,end);
  }
  const isFinal=segmentEnd>=end;

  if(isFinal){
    const next=tasks.map(x=>x.id===id?{...x,status:'unfinished',endedAt:new Date().toISOString()}:x);
    await chrome.storage.local.set({tasks:next});
  }
  const payload={type:'blockit-block-end',id:t.id,title:t.title,start:minutesToTime(segmentStart),end:minutesToTime(segmentEnd),final:isFinal};
  try{await chrome.runtime.sendMessage(payload)}catch(e){}
  if(settings.notifications){
    chrome.notifications.create('block_'+id+'_'+index,{
      type:'basic',iconUrl:'assets/icon128.png',requireInteraction:true,priority:2,
      title:`Blockit — ${isFinal?'Task ended':'Block ended'}`,
      message:`${t.title}: ${minutesToTime(segmentStart)}–${minutesToTime(segmentEnd)}${isFinal?' — task finished.':' — block finished.'}`
    });
  }
  if(isFinal) await openTaskEndWindow(payload, settings);
});

chrome.notifications.onClicked.addListener(id=>{
  chrome.tabs.create({url:chrome.runtime.getURL(id==='daily_review'?'dashboard.html#review':'dashboard.html')});
});
