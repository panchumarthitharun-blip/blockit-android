const DEFAULT_SETTINGS = {
  notifications: true,
  sound: true,
  taskPopup: true,
  dailyReview: true,
  dailyReviewTime: "21:00",
  defaultDuration: 15,
  horizontalBlockMode: "automatic",
  horizontalBlockCount: 4,
  snoozeMinutes: [5,10,15,30],
  workingStart: "08:00",
  workingEnd: "22:00",
  firstDay: 1,
  theme: "light"
};

function uid(prefix='id') { return prefix + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,8); }
function dateKey(d=new Date()) { const x=new Date(d); return `${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,'0')}-${String(x.getDate()).padStart(2,'0')}`; }
function timeToMinutes(t){ const [h,m]=t.split(':').map(Number); return h*60+m; }
function minutesToTime(min){ min=Math.max(0,Math.min(1439,min)); return `${String(Math.floor(min/60)).padStart(2,'0')}:${String(min%60).padStart(2,'0')}`; }
function addDays(key,n){ const d=new Date(key+'T12:00:00'); d.setDate(d.getDate()+n); return dateKey(d); }
async function getState(){
  const s=await chrome.storage.local.get(['tasks','settings','notes','lastReviewDate','completeNotes']);
  const settings={...DEFAULT_SETTINGS,...(s.settings||{})};
  settings.defaultDuration=Math.max(5,Math.min(240,Number(settings.defaultDuration)||15));
  settings.horizontalBlockCount=Math.max(2,Math.min(12,Number(settings.horizontalBlockCount)||4));
  if (!s.settings || !s.settings._timeAlignedV142) { settings.horizontalBlockMode='automatic'; settings._timeAlignedV142=true; }
  if (!['automatic','fixed'].includes(settings.horizontalBlockMode)) settings.horizontalBlockMode='automatic';
  return {tasks:s.tasks||[], settings, notes:s.notes||{}, completeNotes:s.completeNotes||{}, lastReviewDate:s.lastReviewDate||''};
}
async function saveState(state){ await chrome.storage.local.set({tasks:state.tasks,settings:state.settings,notes:state.notes,completeNotes:state.completeNotes||{},lastReviewDate:state.lastReviewDate||''}); }
