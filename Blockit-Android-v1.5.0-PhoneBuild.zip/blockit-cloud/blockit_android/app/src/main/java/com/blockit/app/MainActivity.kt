package com.blockit.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        createNotificationChannel()

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    installChromeCompatibility()
                }
            }
            addJavascriptInterface(AndroidStorage(this@MainActivity), "AndroidStorage")
            loadUrl("file:///android_asset/web/dashboard.html")
        }
        setContentView(webView)
    }

    private fun installChromeCompatibility() {
        val js = """
            (function(){
              if(window.chrome && window.chrome.storage) return;
              window.chrome = window.chrome || {};
              window.chrome.storage = { local: {
                get: function(keys){ return Promise.resolve(JSON.parse(AndroidStorage.get(keys === undefined ? '' : JSON.stringify(keys)))); },
                set: function(obj){ AndroidStorage.set(JSON.stringify(obj)); return Promise.resolve(); },
                remove: function(keys){ AndroidStorage.remove(keys === undefined ? '' : JSON.stringify(keys)); return Promise.resolve(); }
              }};
              window.chrome.runtime = window.chrome.runtime || {};
              window.chrome.runtime.getURL = function(p){ return 'file:///android_asset/web/' + p; };
              window.chrome.runtime.onMessage = window.chrome.runtime.onMessage || { addListener:function(){} };
              window.chrome.runtime.sendMessage = function(){ return Promise.resolve(); };
              window.chrome.tabs = window.chrome.tabs || { create:function(){}, query:function(){return Promise.resolve([]);} };
              window.chrome.alarms = window.chrome.alarms || {getAll:function(){return Promise.resolve([])},create:function(){},clear:function(){return Promise.resolve(true)}};
              window.chrome.notifications = window.chrome.notifications || {create:function(){}};
              window.chrome.windows = window.chrome.windows || {};
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("blockit", "Blockit", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}

class AndroidStorage(private val context: Context) {
    private val prefs by lazy { context.getSharedPreferences("blockit_storage", Context.MODE_PRIVATE) }

    @JavascriptInterface fun get(keysJson: String): String {
        val result = JSONObject()
        if (keysJson.isBlank()) {
            prefs.all.forEach { (key, value) -> if (value is String) { try { result.put(key, JSONObject(value)) } catch (_: Exception) { result.put(key, value) } } }
            return result.toString()
        }
        try {
            val parsed = org.json.JSONTokener(keysJson).nextValue()
            val keys = when (parsed) {
                is org.json.JSONArray -> (0 until parsed.length()).map { parsed.getString(it) }
                is JSONObject -> parsed.keys().asSequence().toList()
                is String -> listOf(parsed)
                else -> emptyList()
            }
            keys.forEach { key ->
                if (prefs.contains(key)) {
                    val raw = prefs.getString(key, null)
                    if (raw != null) { try { result.put(key, org.json.JSONTokener(raw).nextValue()) } catch (_: Exception) { result.put(key, raw) } }
                }
            }
        } catch (_: Exception) {}
        return result.toString()
    }

    @JavascriptInterface fun set(json: String) {
        val obj = JSONObject(json); val e = prefs.edit()
        obj.keys().forEach { key -> e.putString(key, obj.get(key).toString()) }
        e.apply()
    }

    @JavascriptInterface fun remove(keysJson: String) {
        val e = prefs.edit()
        try { val obj = JSONObject(keysJson); obj.keys().forEach { e.remove(it) } } catch (_: Exception) {}
        e.apply()
    }
}
